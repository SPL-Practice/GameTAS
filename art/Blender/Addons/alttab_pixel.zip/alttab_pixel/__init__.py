# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "AltTab Pixel",
    "author" : "sat", 
    "description" : "SECOND PILOTS to Pixel Art",
    "blender" : (3, 2, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_UL_display_collection_list_93D40(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index_93D40):
        row = layout
        layout.label(text=str(bpy.context.active_object.material_slots[index_93D40].material.name), icon_value=get_id_preview_id(bpy.data.materials[bpy.context.active_object.material_slots[index_93D40].material.name]))


def get_id_preview_id(data):
    if hasattr(data, "preview"):
        if not data.preview:
            data.preview_ensure()
        if hasattr(data.preview, "icon_id"):
            return data.preview.icon_id
    return 0


class SNA_OT_Use_Image_Texture_D6Cfd(bpy.types.Operator):
    bl_idname = "sna.use_image_texture_d6cfd"
    bl_label = "Use Image Texture"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.materials", globals(), locals()) and bpy.context.active_object.name + '_TexturedPixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index) in bpy.data.materials):
            bpy.context.active_object.active_material = bpy.data.materials[bpy.context.active_object.name + '_TexturedPixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)]
        else:
            before_data = list(bpy.data.materials)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Material', filename='TexturedPixelMaterial', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.materials)))
            appended_A7273 = None if not new_data else new_data[0]
            bpy.context.scene.sna_lightcolor = bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[1].default_value
            bpy.context.scene.sna_darkcolor = bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[2].default_value
            bpy.context.scene.sna_linecolor = bpy.context.view_layer.objects.active.active_material.line_color
            bpy.context.active_object.active_material = bpy.data.materials['TexturedPixelMaterial']
            bpy.data.materials['TexturedPixelMaterial'].name = bpy.context.active_object.name + '_TexturedPixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)
            bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[1].default_value = bpy.context.scene.sna_lightcolor
            bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[2].default_value = bpy.context.scene.sna_darkcolor
            bpy.context.view_layer.objects.active.active_material.line_color = bpy.context.scene.sna_linecolor
            exec('from .easybpy import *')
            exec('select_object(active_object())')
            exec('')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Stop_Using_Texture_4900C(bpy.types.Operator):
    bl_idname = "sna.stop_using_texture_4900c"
    bl_label = "Stop Using Texture"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.materials", globals(), locals()) and bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index) in bpy.data.materials):
            bpy.context.active_object.active_material = bpy.data.materials[bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Assign_New_Pixel_Material_907F9(bpy.types.Operator):
    bl_idname = "sna.assign_new_pixel_material_907f9"
    bl_label = "Assign New Pixel Material"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.object.material_slot_add('INVOKE_DEFAULT', )
        bpy.context.active_object.active_material = bpy.data.materials[bpy.context.active_object.name + '_PixelMaterial' + str(int(bpy.context.view_layer.objects.active.active_material_index - 1.0))]
        id_F8685 = bpy.context.active_object.active_material.copy()
        bpy.context.active_object.active_material = bpy.data.materials[bpy.context.active_object.name + '_PixelMaterial' + str(int(bpy.context.view_layer.objects.active.active_material_index - 1.0)) + '.001']
        bpy.context.active_object.active_material.name = bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)
        bpy.ops.object.material_slot_assign('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Use_Pixel_Material_A768A(bpy.types.Operator):
    bl_idname = "sna.use_pixel_material_a768a"
    bl_label = "Use Pixel Material"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.materials", globals(), locals()) and bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index) in bpy.data.materials):
            bpy.context.active_object.active_material = bpy.data.materials[bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)]
        else:
            before_data = list(bpy.data.materials)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Material', filename='PixelMaterial', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.materials)))
            appended_EEFB6 = None if not new_data else new_data[0]
            bpy.context.active_object.active_material = bpy.data.materials['PixelMaterial']
            bpy.data.materials['PixelMaterial'].name = bpy.context.active_object.name + '_PixelMaterial' + str(bpy.context.view_layer.objects.active.active_material_index)
            exec('from .easybpy import *')
            exec('select_object(active_object())')
            exec('')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setup_Project_60460(bpy.types.Operator):
    bl_idname = "sna.setup_project_60460"
    bl_label = "Setup Project"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        exec('import bpy')
        exec('from .easybpy import *')
        exec('create_collection("NoOutline")')
        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        bpy.context.scene.eevee.taa_render_samples = 1
        bpy.context.scene.view_settings.view_transform = 'Standard'
        bpy.context.scene.render.filter_size = 0.30000001192092896
        bpy.context.scene.render.resolution_x = 200
        bpy.context.scene.render.resolution_y = 200
        bpy.context.scene.eevee.use_soft_shadows = False
        bpy.context.scene.eevee.shadow_cascade_size = '4096'
        bpy.context.scene.eevee.shadow_cube_size = '4096'
        if bpy.context.view_layer.objects.active:
            bpy.context.scene.render.use_freestyle = True
            bpy.data.linestyles['LineStyle'].thickness = 1.0499999523162842
            bpy.context.view_layer.use_pass_z = True
            bpy.context.view_layer.freestyle_settings.linesets.active.select_contour = True
            bpy.context.view_layer.freestyle_settings.linesets.active.select_by_collection = True
            bpy.context.view_layer.freestyle_settings.linesets.active.collection_negation = 'EXCLUSIVE'
            bpy.context.view_layer.freestyle_settings.linesets.active.collection = bpy.data.collections['NoOutline']
            modifier_E97B6 = bpy.context.view_layer.freestyle_settings.linesets['LineSet'].linestyle.color_modifiers.new(name='', type='MATERIAL', )
        else:
            bpy.ops.object.light_add('INVOKE_DEFAULT', type='SUN', location=(0.0, 0.0, 10.0))
            bpy.context.scene.render.use_freestyle = True
            bpy.data.linestyles['LineStyle'].thickness = 1.0499999523162842
            bpy.context.view_layer.use_pass_z = True
            bpy.context.view_layer.freestyle_settings.linesets.active.select_contour = True
            bpy.context.view_layer.freestyle_settings.linesets.active.select_by_collection = True
            bpy.context.view_layer.freestyle_settings.linesets.active.collection_negation = 'EXCLUSIVE'
            bpy.context.view_layer.freestyle_settings.linesets.active.collection = bpy.data.collections['NoOutline']
            modifier_3D79F = bpy.context.view_layer.freestyle_settings.linesets['LineSet'].linestyle.color_modifiers.new(name='', type='MATERIAL', )
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text='All set up!', icon_value=0)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Import__Rf_1B149(bpy.types.Operator):
    bl_idname = "sna.import__rf_1b149"
    bl_label = "Import  RF"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.objects", globals(), locals()) and 'Isometric RF' in bpy.data.objects):
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric RF']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        else:
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Object', filename='Isometric RF', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_B0848 = None if not new_data else new_data[0]
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric RF']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Import_Lf_36687(bpy.types.Operator):
    bl_idname = "sna.import_lf_36687"
    bl_label = "Import LF"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.objects", globals(), locals()) and 'Isometric LF' in bpy.data.objects):
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric LF']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        else:
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Object', filename='Isometric LF', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_2B827 = None if not new_data else new_data[0]
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric LF']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Import_Lb_2Fb4F(bpy.types.Operator):
    bl_idname = "sna.import_lb_2fb4f"
    bl_label = "Import LB"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.objects", globals(), locals()) and 'Isometric LB' in bpy.data.objects):
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric LB']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        else:
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Object', filename='Isometric LB', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_5DFB2 = None if not new_data else new_data[0]
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric LB']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Import_Rb_B68B5(bpy.types.Operator):
    bl_idname = "sna.import_rb_b68b5"
    bl_label = "Import RB"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if (property_exists("bpy.data.objects", globals(), locals()) and 'Isometric RB' in bpy.data.objects):
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric RB']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        else:
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Assets.blend') + r'\Object', filename='Isometric RB', link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_73E3B = None if not new_data else new_data[0]
            bpy.context.view_layer.objects.active = bpy.context.layer_collection.collection.all_objects['Isometric RB']
            bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Your_Camera_B2Eac(bpy.types.Operator):
    bl_idname = "sna.add_your_camera_b2eac"
    bl_label = "Add Your Camera"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.ops.object.camera_add('INVOKE_DEFAULT', )
        bpy.ops.view3d.object_as_camera('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_ALTTAB_PIXEL_CF984(bpy.types.Panel):
    bl_label = 'AltTab Pixel'
    bl_idname = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AltTab Pixel'
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout


class SNA_PT_UTILITY_2EF5E(bpy.types.Panel):
    bl_label = 'Utility'
    bl_idname = 'SNA_PT_UTILITY_2EF5E'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'EDIT_MESH'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_B0C30 = layout.box()
        box_B0C30.alert = False
        box_B0C30.enabled = True
        box_B0C30.active = True
        box_B0C30.use_property_split = False
        box_B0C30.use_property_decorate = False
        box_B0C30.alignment = 'Expand'.upper()
        box_B0C30.scale_x = 1.0
        box_B0C30.scale_y = 1.0
        op = box_B0C30.operator('sna.assign_new_pixel_material_907f9', text='Assign New Pixel Material', icon_value=0, emboss=True, depress=False)


class SNA_PT_SETUP_E07DF(bpy.types.Panel):
    bl_label = 'Setup'
    bl_idname = 'SNA_PT_SETUP_E07DF'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HEADER_LAYOUT_EXPAND', 'DEFAULT_CLOSED'}
    bl_parent_id = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ('EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.setup_project_60460', text='Setup Project', icon_value=0, emboss=True, depress=False)
        layout.prop(bpy.data.scenes['Scene'].render, 'film_transparent', text='Transparent', icon_value=0, emboss=True)


class SNA_PT_PIXEL_CAMERAS_EDC9D(bpy.types.Panel):
    bl_label = 'Pixel Cameras'
    bl_idname = 'SNA_PT_PIXEL_CAMERAS_EDC9D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ('EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_60508 = layout.column(heading='', align=True)
        col_60508.alert = False
        col_60508.enabled = True
        col_60508.use_property_split = False
        col_60508.use_property_decorate = False
        col_60508.scale_x = 1.0
        col_60508.scale_y = 1.0
        col_60508.alignment = 'Expand'.upper()
        col_60508.label(text='Use Pixel Camera', icon_value=0)
        row_B95A5 = col_60508.row(heading='', align=True)
        row_B95A5.alert = False
        row_B95A5.enabled = True
        row_B95A5.use_property_split = False
        row_B95A5.use_property_decorate = False
        row_B95A5.scale_x = 1.0
        row_B95A5.scale_y = 1.0
        row_B95A5.alignment = 'Expand'.upper()
        op = row_B95A5.operator('sna.import_lf_36687', text='Isometric LF', icon_value=0, emboss=True, depress=False)
        row_B95A5.separator(factor=1.0)
        op = row_B95A5.operator('sna.import__rf_1b149', text='Isometric RF', icon_value=0, emboss=True, depress=False)
        row_9E824 = col_60508.row(heading='', align=True)
        row_9E824.alert = False
        row_9E824.enabled = True
        row_9E824.use_property_split = False
        row_9E824.use_property_decorate = False
        row_9E824.scale_x = 1.0
        row_9E824.scale_y = 1.0
        row_9E824.alignment = 'Expand'.upper()
        op = row_9E824.operator('sna.import_lb_2fb4f', text='Isometric LB', icon_value=0, emboss=True, depress=False)
        row_9E824.separator(factor=1.0)
        op = row_9E824.operator('sna.import_rb_b68b5', text='Isometric RB', icon_value=0, emboss=True, depress=False)
        col_60508.label(text='Use Your Own Camera', icon_value=0)
        op = col_60508.operator('sna.add_your_camera_b2eac', text='Add Your Camera', icon_value=0, emboss=True, depress=False)


class SNA_PT_CAMERA_CONTROL_9BE24(bpy.types.Panel):
    bl_label = 'Camera Control'
    bl_idname = 'SNA_PT_CAMERA_CONTROL_9BE24'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_PIXEL_CAMERAS_EDC9D'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if ('ORTHO' == bpy.context.scene.camera.data.type):
            col_55D3D = layout.column(heading='', align=False)
            col_55D3D.alert = False
            col_55D3D.enabled = True
            col_55D3D.active = True
            col_55D3D.use_property_split = False
            col_55D3D.use_property_decorate = False
            col_55D3D.scale_x = 1.0
            col_55D3D.scale_y = 1.0
            col_55D3D.alignment = 'Expand'.upper()
            col_55D3D.prop(bpy.context.scene.camera.data, 'shift_x', text='Shift X', icon_value=0, emboss=True)
            col_55D3D.prop(bpy.context.scene.camera.data, 'shift_y', text='Shift Y', icon_value=0, emboss=True)
            col_55D3D.prop(bpy.context.scene.camera.data, 'ortho_scale', text='Otrhographic Scale', icon_value=0, emboss=True)
        else:
            col_115AA = layout.column(heading='', align=False)
            col_115AA.alert = False
            col_115AA.enabled = True
            col_115AA.active = True
            col_115AA.use_property_split = False
            col_115AA.use_property_decorate = False
            col_115AA.scale_x = 1.0
            col_115AA.scale_y = 1.0
            col_115AA.alignment = 'Expand'.upper()
            col_115AA.label(text='Location:', icon_value=0)
            col_115AA.prop(bpy.context.view_layer.objects.active, 'location', text='', icon_value=0, emboss=True)
            col_115AA.label(text='Rotation:', icon_value=0)
            col_115AA.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='', icon_value=0, emboss=True)
            col_115AA.separator(factor=1.0)
            col_115AA.label(text='Sensor Size:', icon_value=0)
            col_115AA.prop(bpy.context.scene.camera.data, 'lens', text='', icon_value=0, emboss=True)


class SNA_PT_MATERIAL_CONTROL_8B8E1(bpy.types.Panel):
    bl_label = 'Material Control'
    bl_idname = 'SNA_PT_MATERIAL_CONTROL_8B8E1'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (('EDIT_MESH'==bpy.context.mode or (not bpy.context.view_layer.objects.active)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if ((not bpy.context.active_object.active_material) or (not 'Pixel' in bpy.context.active_object.active_material.name)):
            box_FCBC9 = layout.box()
            box_FCBC9.alert = False
            box_FCBC9.enabled = True
            box_FCBC9.active = True
            box_FCBC9.use_property_split = False
            box_FCBC9.use_property_decorate = False
            box_FCBC9.alignment = 'Expand'.upper()
            box_FCBC9.scale_x = 1.0
            box_FCBC9.scale_y = 1.0
            op = box_FCBC9.operator('sna.use_pixel_material_a768a', text='Use Pixel Material', icon_value=0, emboss=True, depress=False)
        else:
            col_158E7 = layout.column(heading='', align=False)
            col_158E7.alert = False
            col_158E7.enabled = True
            col_158E7.active = True
            col_158E7.use_property_split = False
            col_158E7.use_property_decorate = False
            col_158E7.scale_x = 1.0
            col_158E7.scale_y = 1.0
            col_158E7.alignment = 'Expand'.upper()
            col_158E7.prop(bpy.context.active_object.active_material, 'name', text='Material', icon_value=0, emboss=False)
            row_D3805 = col_158E7.row(heading='', align=True)
            row_D3805.alert = False
            row_D3805.enabled = True
            row_D3805.active = True
            row_D3805.use_property_split = False
            row_D3805.use_property_decorate = False
            row_D3805.scale_x = 1.0
            row_D3805.scale_y = 1.0
            row_D3805.alignment = 'Expand'.upper()
            op = row_D3805.operator('object.shade_smooth', text='Shade Smooth', icon_value=0, emboss=True, depress=False)
            op = row_D3805.operator('object.shade_flat', text='Shade Flat', icon_value=0, emboss=True, depress=False)
            col_158E7.label(text='Lighting Threshold', icon_value=0)
            row_0C29D = col_158E7.row(heading='', align=True)
            row_0C29D.alert = False
            row_0C29D.enabled = True
            row_0C29D.active = True
            row_0C29D.use_property_split = False
            row_0C29D.use_property_decorate = False
            row_0C29D.scale_x = 1.0
            row_0C29D.scale_y = 1.0
            row_0C29D.alignment = 'Expand'.upper()
            row_0C29D.prop(bpy.context.active_object.active_material.node_tree.nodes['ColorRamp'].color_ramp.elements[0], 'position', text='', icon_value=0, emboss=True)
            row_0C29D.prop(bpy.context.active_object.active_material.node_tree.nodes['ColorRamp'].color_ramp.elements[1], 'position', text='', icon_value=0, emboss=True)
            row_0C29D.prop(bpy.context.active_object.active_material.node_tree.nodes['ColorRamp'].color_ramp.elements[2], 'position', text='', icon_value=0, emboss=True)
            col_158E7.label(text='Color: Light/Shadow/Outline', icon_value=0)
            row_4181E = col_158E7.row(heading='', align=False)
            row_4181E.alert = False
            row_4181E.enabled = True
            row_4181E.active = True
            row_4181E.use_property_split = False
            row_4181E.use_property_decorate = False
            row_4181E.scale_x = 1.0
            row_4181E.scale_y = 1.0
            row_4181E.alignment = 'Expand'.upper()
            row_4181E.prop(bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[1], 'default_value', text='', icon_value=0, emboss=True)
            row_4181E.prop(bpy.context.view_layer.objects.active.active_material.node_tree.nodes['Mix'].inputs[2], 'default_value', text='', icon_value=0, emboss=True)
            row_4181E.prop(bpy.context.view_layer.objects.active.active_material, 'line_color', text='', icon_value=0, emboss=True)
            if 'Textured' in bpy.context.active_object.active_material.name:
                box_48DD5 = col_158E7.box()
                box_48DD5.alert = False
                box_48DD5.enabled = True
                box_48DD5.active = True
                box_48DD5.use_property_split = False
                box_48DD5.use_property_decorate = False
                box_48DD5.alignment = 'Expand'.upper()
                box_48DD5.scale_x = 1.0
                box_48DD5.scale_y = 1.0
                col_D8DD6 = box_48DD5.column(heading='', align=False)
                col_D8DD6.alert = False
                col_D8DD6.enabled = True
                col_D8DD6.active = True
                col_D8DD6.use_property_split = False
                col_D8DD6.use_property_decorate = False
                col_D8DD6.scale_x = 1.0
                col_D8DD6.scale_y = 1.0
                col_D8DD6.alignment = 'Expand'.upper()
                col_D8DD6.label(text='Image Texture', icon_value=0)
                exec("col_D8DD6.template_ID(bpy.context.active_object.active_material.node_tree.nodes['Image Texture'], 'image', open='image.open', new='image.new')" + '')
                col_D8DD6.prop(bpy.context.active_object.active_material.node_tree.nodes['Invert'].inputs['Fac'], 'default_value', text='Invert', icon_value=0, emboss=True)
                op = col_D8DD6.operator('sna.stop_using_texture_4900c', text='Stop Using Texture', icon_value=778, emboss=True, depress=False)
            else:
                op = col_158E7.operator('sna.use_image_texture_d6cfd', text='Use Image Texture', icon_value=0, emboss=True, depress=False)
        layout.template_list('SNA_UL_display_collection_list_93D40', '93D40', bpy.context.active_object, 'material_slots', bpy.context.view_layer.objects.active, 'active_material_index', rows=3)


class SNA_PT_OUTLINE_SETTINGS_EE47A(bpy.types.Panel):
    bl_label = 'Outline Settings'
    bl_idname = 'SNA_PT_OUTLINE_SETTINGS_EE47A'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_ALTTAB_PIXEL_CF984'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ('EDIT_MESH'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Outline Thickness', icon_value=0)
        layout.prop(bpy.data.linestyles['LineStyle'], 'thickness', text='', icon_value=0, emboss=True)
        layout.label(text='Edge Type ', icon_value=0)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_silhouette', text='Silhouette', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_crease', text='Crease', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_border', text='Border', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_edge_mark', text='Edge Mark', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_contour', text='Contour', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_external_contour', text='External Contour', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_material_boundary', text='Material Boundary', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_suggestive_contour', text='Suggestive Contour', icon_value=0, emboss=True)
        layout.prop(bpy.context.view_layer.freestyle_settings.linesets.active, 'select_ridge_valley', text='Ridge & Valley', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_userengine = bpy.props.StringProperty(name='UserENGINE', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_userrender_samples = bpy.props.IntProperty(name='UserRENDER_SAMPLES', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_usercolor_profile = bpy.props.StringProperty(name='UserCOLOR_PROFILE', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_userfilter_size = bpy.props.FloatProperty(name='UserFILTER_SIZE', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_userreso_x = bpy.props.IntProperty(name='UserRESO_X', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_userreso_y = bpy.props.IntProperty(name='UserRESO_Y', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_usersoft_shadows = bpy.props.BoolProperty(name='UserSOFT_SHADOWS', description='', default=False)
    bpy.types.Scene.sna_usercascade_size = bpy.props.StringProperty(name='UserCASCADE_SIZE', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_usercube_size = bpy.props.StringProperty(name='UserCUBE_SIZE', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_lightcolor = bpy.props.FloatVectorProperty(name='LightColor', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_darkcolor = bpy.props.FloatVectorProperty(name='DarkColor', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.types.Scene.sna_linecolor = bpy.props.FloatVectorProperty(name='LineColor', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='NONE', unit='NONE', step=3, precision=6)
    bpy.utils.register_class(SNA_OT_Use_Image_Texture_D6Cfd)
    bpy.utils.register_class(SNA_OT_Stop_Using_Texture_4900C)
    bpy.utils.register_class(SNA_OT_Assign_New_Pixel_Material_907F9)
    bpy.utils.register_class(SNA_OT_Use_Pixel_Material_A768A)
    bpy.utils.register_class(SNA_OT_Setup_Project_60460)
    bpy.utils.register_class(SNA_OT_Import__Rf_1B149)
    bpy.utils.register_class(SNA_OT_Import_Lf_36687)
    bpy.utils.register_class(SNA_OT_Import_Lb_2Fb4F)
    bpy.utils.register_class(SNA_OT_Import_Rb_B68B5)
    bpy.utils.register_class(SNA_OT_Add_Your_Camera_B2Eac)
    bpy.utils.register_class(SNA_PT_ALTTAB_PIXEL_CF984)
    bpy.utils.register_class(SNA_PT_UTILITY_2EF5E)
    bpy.utils.register_class(SNA_PT_SETUP_E07DF)
    bpy.utils.register_class(SNA_PT_PIXEL_CAMERAS_EDC9D)
    bpy.utils.register_class(SNA_PT_CAMERA_CONTROL_9BE24)
    bpy.utils.register_class(SNA_PT_MATERIAL_CONTROL_8B8E1)
    bpy.utils.register_class(SNA_UL_display_collection_list_93D40)
    bpy.utils.register_class(SNA_PT_OUTLINE_SETTINGS_EE47A)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_linecolor
    del bpy.types.Scene.sna_darkcolor
    del bpy.types.Scene.sna_lightcolor
    del bpy.types.Scene.sna_usercube_size
    del bpy.types.Scene.sna_usercascade_size
    del bpy.types.Scene.sna_usersoft_shadows
    del bpy.types.Scene.sna_userreso_y
    del bpy.types.Scene.sna_userreso_x
    del bpy.types.Scene.sna_userfilter_size
    del bpy.types.Scene.sna_usercolor_profile
    del bpy.types.Scene.sna_userrender_samples
    del bpy.types.Scene.sna_userengine
    bpy.utils.unregister_class(SNA_OT_Use_Image_Texture_D6Cfd)
    bpy.utils.unregister_class(SNA_OT_Stop_Using_Texture_4900C)
    bpy.utils.unregister_class(SNA_OT_Assign_New_Pixel_Material_907F9)
    bpy.utils.unregister_class(SNA_OT_Use_Pixel_Material_A768A)
    bpy.utils.unregister_class(SNA_OT_Setup_Project_60460)
    bpy.utils.unregister_class(SNA_OT_Import__Rf_1B149)
    bpy.utils.unregister_class(SNA_OT_Import_Lf_36687)
    bpy.utils.unregister_class(SNA_OT_Import_Lb_2Fb4F)
    bpy.utils.unregister_class(SNA_OT_Import_Rb_B68B5)
    bpy.utils.unregister_class(SNA_OT_Add_Your_Camera_B2Eac)
    bpy.utils.unregister_class(SNA_PT_ALTTAB_PIXEL_CF984)
    bpy.utils.unregister_class(SNA_PT_UTILITY_2EF5E)
    bpy.utils.unregister_class(SNA_PT_SETUP_E07DF)
    bpy.utils.unregister_class(SNA_PT_PIXEL_CAMERAS_EDC9D)
    bpy.utils.unregister_class(SNA_PT_CAMERA_CONTROL_9BE24)
    bpy.utils.unregister_class(SNA_PT_MATERIAL_CONTROL_8B8E1)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_93D40)
    bpy.utils.unregister_class(SNA_PT_OUTLINE_SETTINGS_EE47A)
